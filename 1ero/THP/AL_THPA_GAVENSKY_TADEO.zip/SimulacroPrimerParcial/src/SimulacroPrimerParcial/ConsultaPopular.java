package SimulacroPrimerParcial;

import java.util.Scanner;

public class ConsultaPopular {
	final static Scanner scanner = new Scanner(System.in);
	final static int EDAD_MINIMA = 18;

	public static void main(String[] args) {

		char voto;

		int votoS, votoN, votoB;
		int edad;
		int acumEdad = 0, totalVotos = 0;
		double porcentajeEnContra;
		votoS = votoN = votoB = 0;

		System.out.println("Ingrese el voto de la persona (S, N, B) o F para finalizar:");
		voto = scanner.next().toUpperCase().charAt(0);

		while (voto != 'F') {
			System.out.println("Ingrese la edad:");
			edad = Integer.parseInt(scanner.next());
			while (edad < EDAD_MINIMA) {
				System.out.println("La persona debe ser mayor de edad. Ingrese la edad:");
				edad = Integer.parseInt(scanner.next());
			}
			acumEdad += edad;

			switch (voto) {
			case 'S':
				votoS++;
				break;
			case 'N':
				votoN++;
				break;
			case 'B':
				votoB++;
				break;
			default:
				System.out.println("Voto inválido.");
			}

			System.out.println("Ingrese el voto de la persona (S, N, B) o F para finalizar:");
			voto = scanner.next().toUpperCase().charAt(0);

		}
		if (votoS == 0 && votoN == 0 && votoB == 0) {
			System.out.println("No se ingresaron votos.");
		} else {
			totalVotos = votoS + votoN + votoB;
			porcentajeEnContra = (votoN * 100) / totalVotos;
			System.out.println("");
			if (votoS > votoN) {
				System.out.println("Si");
			} else if (votoB > votoS && votoB > votoN) {
				System.out.println("Indeterminado");
			} else {
				System.out.println("No");
			}

			System.out.println("");
			System.out.println("El porcentaje de votos en contra es: " + porcentajeEnContra + "%");
			System.out.println("");
			System.out.println("El promedio de edad de los votantes es: " + acumEdad / totalVotos);
		}

	}

}
