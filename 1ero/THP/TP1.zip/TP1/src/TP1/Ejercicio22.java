package TP1;



public class Ejercicio22 {

	public static void main(String[] args) {
		
		System.out.println("Numeros del 1 al 5");
		for (int i = 1; i <= 5; i++) {
			System.out.println(i);
		}
		

		System.out.println("Numeros del 5 al 1");
		for (int i = 5; i >= 1; i--) {
			System.out.println(i);
		}
	}
}
