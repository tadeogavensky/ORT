package TP1;


import java.util.Scanner;

public class Ejercicio1 {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String nombre;
		
		
		System.out.println("Ingrese su nombre: ");
		nombre = scanner.nextLine();
		
		
		System.out.println("Hola "+ nombre +"!");
		
		
	}

}
