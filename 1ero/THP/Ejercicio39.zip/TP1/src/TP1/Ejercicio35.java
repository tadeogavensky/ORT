package TP1;

import java.util.Scanner;

public class Ejercicio35 {
	final static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		int edad, edadMasJoven = Integer.MAX_VALUE;
		String nombre, nombreMasJoven = "";

		do {
			System.out.println("Ingrese el nombre:");
			nombre = scanner.nextLine();

			if (!nombre.equals("*")) {
				System.out.println("Ingrese la edad:");
				while (!scanner.hasNextInt()) {
					System.out.println("Por favor, ingrese un número válido para la edad:");
					scanner.next(); 
				}
				edad = scanner.nextInt();
				scanner.nextLine(); 

				if (edad < edadMasJoven) {
					edadMasJoven = edad;
					nombreMasJoven = nombre;
				}
			}
		} while (!nombre.equals("*"));

		if (!nombreMasJoven.isEmpty()) {
			System.out.println("La persona más joven es: " + nombreMasJoven);
		} else {
			System.out.println("No se ingresaron personas.");
		}
	}
}