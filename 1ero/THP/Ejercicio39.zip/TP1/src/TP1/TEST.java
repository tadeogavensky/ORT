package TP1;

import java.util.Scanner;

public class TEST {
	

}
