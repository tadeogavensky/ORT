package TP1;

import java.util.Scanner;

public class Ejercicio39 {
	final static Scanner scanner = new Scanner(System.in);
	final static int JUGADORES_MIN = 2;
	final static int TIROS_MAX = 3;

	public static void main(String[] args) {
		String nombre, ganador = "";
		int tirosAlCentro = 0, puntaje = 0, jugadores, puntajeMaximo = 0;
		double distancia;

		System.out.println("Ingrese la cantidad de jugadores (minimo 2):");
		jugadores = scanner.nextInt();
		while (jugadores < JUGADORES_MIN) {
			System.out.println("La cantidad de jugadores debe ser mayor a 2");
			System.out.println("Ingrese la cantidad de jugadores (minimo 2):");
			jugadores = scanner.nextInt();

		}

		scanner.nextLine();

		for (int i = 1; i <= jugadores; i++) {
			System.out.println("Ingrese el nombre del jugador " + i + ":");
			nombre = scanner.nextLine();

			puntaje = 0;
		
			for (int j = 1; j <= TIROS_MAX; j++) {
				System.out.println("Tiro " + j + " - Jugador: " + nombre);
				System.out.println("Ingrese la distancia al centro del jugador " + i + ":");
				distancia = scanner.nextDouble();
				while (distancia < 0) {
					System.out.println("La distancia no puede ser negativa. Ingrese la distancia al centro del jugador "
							+ i + ":");
					distancia = scanner.nextDouble();
				}

				tirosAlCentro++;
				if (distancia == 0) {
					puntaje += 500;
				} else if (distancia <= 10) {
					puntaje += 250;
				} else if (distancia >= 11 && distancia <= 50) {
					puntaje += 100;
				} else {
					puntaje += 0;
					tirosAlCentro--;
				}

				System.out.println("Puntaje acumulado: " + puntaje);
				System.out.println("Tiros al centro acumulados" + tirosAlCentro);

				if (puntaje > puntajeMaximo) {
					puntajeMaximo = puntaje;
					ganador = nombre;
					System.out.println("El ganador actual es " + ganador + " con " + puntajeMaximo + " puntos.");
				}
			}
			scanner.nextLine();
		}

		System.out.println("El ganador es " + ganador + " con " + puntajeMaximo + " puntos.");
		System.out.println("La cantidad de tiros al centro fue de: " + tirosAlCentro);

	}

}
