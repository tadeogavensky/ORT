package simulacros;

import java.util.Scanner;

public class Motores {
	final static Scanner scanner = new Scanner(System.in);
	final static int VALOR_DESEADO = 5;
	final static int PRUEBAS_MAX = 3;
	final static double COEFICIENTE_MIN = 3.5;

	public static void main(String[] args) {
		int empuje, energia;
		int pruebas = 0, contadorMayorA5 = 0;
		double coeficiente = 0;
		boolean esViable = false, esMayorA5 = false;

		do {
			
			
			System.out.println("Ingrese el empuje (entre 0 y 1000):");
			empuje = scanner.nextInt();

			while (empuje < 0 || empuje > 1000) {
				System.out.println("ATENCIÓN! Ingrese empuje generado (entre 0 y 1000): ");
				empuje = scanner.nextInt();
			}

			System.out.println("Ingrese la energia generado (entre 1 y 500): ");
			energia = scanner.nextInt();
			while (energia < 1 || energia > 500) {
				System.out.println("ATENCIÓN! Ingrese energia generado (entre 1 y 500): ");
				energia = scanner.nextInt();
			}
			
			pruebas++;

			coeficiente = (double) empuje / energia;
			
			esViable = coeficiente >= COEFICIENTE_MIN;
			


			if (esViable && coeficiente >= VALOR_DESEADO) {
				esMayorA5 = true;
				contadorMayorA5++;
			}
			
			
			
			System.out.println("Prueba: " + pruebas);
			System.out.println("Coeficiente: " + coeficiente);
			System.out.println("Es viable: " + esViable);
			
		} while (pruebas < PRUEBAS_MAX && esViable);

		if (esViable && esMayorA5) {
			System.out.println("PROTOTIPO VIABLE");
			System.out.println("Cantidad de pruebas con coeficiente mayor a 5: " + contadorMayorA5);
		} else if (!esViable) {
			System.out.println("RENDIMIENTO INSUFICIENTE");
			System.out.println("El coeficiente fue menor a " + COEFICIENTE_MIN);
		} else {
			System.out.println("OBJETIVO NO ALCANZADO");
			System.out.println("El coeficiente fue mayor a " + COEFICIENTE_MIN
					+ " y en ninguna prueba cumplio con el valor deseado de ser " + VALOR_DESEADO + " o mayor");
		}

	}

}
